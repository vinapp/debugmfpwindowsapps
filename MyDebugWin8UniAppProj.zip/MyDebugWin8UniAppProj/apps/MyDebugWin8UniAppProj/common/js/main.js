function wlCommonInit(){
	/*
	 * Use of WL.Client.connect() API before any connectivity to a MobileFirst Server is required. 
	 * This API should be called only once, before any other WL.Client methods that communicate with the MobileFirst Server.
	 * Don't forget to specify and implement onSuccess and onFailure callback functions for WL.Client.connect(), e.g:
	 *    
	 *    WL.Client.connect({
	 *    		onSuccess: onConnectSuccess,
	 *    		onFailure: onConnectFailure
	 *    });
	 *     
	 */
	
	// Common initialization code goes here
	
	/*
     * This is a call to the managed code (C#). 
     * The below code calls a "pluginCall" method on "MyDebugDllPlugin" plugin.
     */
	
	 console.log("Calling the plugin  --- MyDebugDll.MyDebugDllPlugin.pluginCall ");

	 MyDebugDll.MyDebugDllPlugin.pluginCall("return the this string length").done(
	 //When the result has completed, check the status.
	 function completed(result) {
	    if (result.isSuccess) {
	        console.log("Success - from c#/c++/c layer "+ result.value);
	    } else {
	        console.log("Failure - from c#/c++/c layer");
	    }
	 });
}
