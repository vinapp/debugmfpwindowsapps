﻿#include "pch.h"
#include "MYcppClass.h"

using namespace CPPWinRT;
using namespace Platform;

/*
 * This is a native code (C++/C).
 * The below code return the length of the string passed (Script/ManagedCode (C#)).
 */

unsigned int StringCharacterCounter::GetLength(String^ strToParse) {
	std::wstring stlString = strToParse->Data();

	return stlString.length();
}
