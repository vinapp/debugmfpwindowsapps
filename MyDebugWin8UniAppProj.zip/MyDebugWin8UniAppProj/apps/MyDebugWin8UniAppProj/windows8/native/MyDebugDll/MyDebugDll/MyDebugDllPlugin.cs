﻿/*
 * IBM Confidential OCO Source Materials
 * 
 * 5725-I43 Copyright IBM Corp. 2014
 * 
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 * 
*/

using System;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;

namespace MyDebugDll
{
    public sealed class MyDebugDllPlugin
    {
        public static IAsyncOperation<PluginResult> pluginCall(string parameters)
        {
            return AsyncInfo.Run((token) =>
                Task.Run<PluginResult>(() =>
                {
                    try
                    {
                        /*
                         * The below code (i.e. Managed Code (C#)) calls the native code (method - GetLength) to get the length of the string.
                         * The returned result from the native is passed back to the Javascript layer.
                         */
                        CPPWinRT.StringCharacterCounter sccMain = new CPPWinRT.StringCharacterCounter();
                        String txt = sccMain.GetLength(parameters).ToString();
                        return new PluginResult(Status.OK, txt);
                    }
                    catch (Exception ex)
                    {
                        return new PluginResult(Status.ERROR);
                    }
                }, token));
        }
    }
}
