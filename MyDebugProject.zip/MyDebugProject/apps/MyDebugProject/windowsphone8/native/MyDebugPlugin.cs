/*
 * IBM Confidential OCO Source Materials
 * 
 * 5725-I43 Copyright IBM Corp. 2014
 * 
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 * 
*/

using IBM.Worklight;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using WPCordovaClassLib.Cordova;
using WPCordovaClassLib.Cordova.Commands;
using WPCordovaClassLib.Cordova.JSON;

namespace Cordova.Extension.Commands
{
    /*
     * Simple Plugin (C#/Managed code) called from JavaScript layer (using cordova.exec() in main.js code) 
     * that will return a value back to JavaScript
     * 
     */
    public class MyDebugPlugin : BaseCommand
    {        
        public MyDebugPlugin()
        {            
        }

        public void printToConsole(string options)
        {
			Debug.WriteLine("This (C#/Managed) output logged in Visual studio console");
            PluginResult result = new PluginResult(PluginResult.Status.OK, "value from managed code");
            DispatchCommandResult(result);//send the result to javascript layer
        }
       
    }
}