function wlCommonInit(){
	/*
	 * Use of WL.Client.connect() API before any connectivity to a MobileFirst Server is required. 
	 * This API should be called only once, before any other WL.Client methods that communicate with the MobileFirst Server.
	 * Don't forget to specify and implement onSuccess and onFailure callback functions for WL.Client.connect(), e.g:
	 *    
	 *    WL.Client.connect({
	 *    		onSuccess: onConnectSuccess,
	 *    		onFailure: onConnectFailure
	 *    });
	 *     
	 */
	
	// Common initialization code goes here
	
	/*
     * This is a Cordova call to the managed code (C#). 
     * The below code calls a method "printToConsole" on the plugin "MyDebugPlugin".
     * Note: Plugin entry should exist in Config.xml.
     */
	
    cordova.exec(
        function (result) {
            //alert("success - " + JSON.stringify(result));
            console.log("--- plugin output (success)--- " + JSON.stringify(result));
        },
        function (result) {
            //alert("failure - " + JSON.stringify(result));
            console.log("--- plugin output (failure) --- " + JSON.stringify(result));
        },
        'MyDebugPlugin', 'printToConsole', []
   );
}

/*
 * Connects to the worklight server (XHR Call) and 
 * callbacks "onConnectSuccess" or "onConnectFailure" is invoked depending 
 * on connection successful or failure to the server.
 *
 */
function MFPServerConnect() {
	WL.Client.connect({
 		onSuccess: onConnectSuccess,
 		onFailure: onConnectFailure
	});
}

function onConnectSuccess (result) {
	console.log("Server call (XHR Call) succeded");
}

function onConnectFailure (result) {
	console.log("Server call (XHR Call) failed");
}
